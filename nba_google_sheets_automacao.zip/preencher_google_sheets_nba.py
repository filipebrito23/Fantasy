import re
import time
import pandas as pd
import requests
import gspread
from io import StringIO
from datetime import datetime
from bs4 import BeautifulSoup
from google.oauth2.service_account import Credentials

SPREADSHEET_ID = "1IiJb0iJW4Vnqyh5CFs8jZOSSZqlmdBGbWJCPFoNO4ao"
SERVICE_ACCOUNT_FILE = "service_account.json"
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]
COLUNAS_OBRIGATORIAS = ["Jogadores", "Time Mandante", "Data"]
COLUNAS_STATS = ["Pontos", "Rebotes", "Assistências", "Roubos", "Tocos", "Bolas de 3", "Turnovers"]
NBA_TEAMS = {
    "Atlanta Hawks": "ATL","Boston Celtics": "BOS","Brooklyn Nets": "BRK","Charlotte Hornets": "CHO",
    "Chicago Bulls": "CHI","Cleveland Cavaliers": "CLE","Dallas Mavericks": "DAL","Denver Nuggets": "DEN",
    "Detroit Pistons": "DET","Golden State Warriors": "GSW","Houston Rockets": "HOU","Indiana Pacers": "IND",
    "Los Angeles Clippers": "LAC","Los Angeles Lakers": "LAL","Memphis Grizzlies": "MEM","Miami Heat": "MIA",
    "Milwaukee Bucks": "MIL","Minnesota Timberwolves": "MIN","New Orleans Pelicans": "NOP","New York Knicks": "NYK",
    "Oklahoma City Thunder": "OKC","Orlando Magic": "ORL","Philadelphia 76ers": "PHI","Phoenix Suns": "PHX",
    "Portland Trail Blazers": "POR","Sacramento Kings": "SAC","San Antonio Spurs": "SAS","Toronto Raptors": "TOR",
    "Utah Jazz": "UTA","Washington Wizards": "WAS"
}

def conectar_gsheets():
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    gc = gspread.authorize(creds)
    return gc.open_by_key(SPREADSHEET_ID)

def parse_data(data_str):
    try:
        dt = datetime.strptime(str(data_str).strip(), "%d/%m/%y")
        return dt.strftime("%Y%m%d")
    except:
        return None

def normalizar_nome(nome):
    if pd.isna(nome): return ""
    nome = str(nome).strip().lower()
    nome = re.sub(r"[*\.]", "", nome)
    return re.sub(r"\s+", " ", nome)

def encontrar_jogador(df_box, player_name):
    if df_box.empty: return None
    if df_box.columns.nlevels > 1:
        df_box.columns = df_box.columns.droplevel()
    player_col = df_box.columns[0]
    df_box[player_col] = df_box[player_col].astype(str).str.strip()
    alvo = normalizar_nome(player_name)
    for idx, player in df_box[player_col].items():
        atual = normalizar_nome(player)
        if atual == alvo or alvo in atual or atual in alvo:
            return idx, df_box
    return None

def find_player_stats(team_abbr, game_date, player_name):
    game_id = f"{game_date}{team_abbr}0"
    url = f"https://www.basketball-reference.com/boxscores/{game_id}.html"
    vazio = {k: "" for k in COLUNAS_STATS}
    try:
        resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
        if resp.status_code != 200: return vazio
        html = resp.text.replace("<!--", "").replace("-->", "")
        soup = BeautifulSoup(html, "html.parser")
        tables = soup.find_all("table", id=re.compile(r"box-.+-game-basic"))
        for table in tables:
            try:
                df_box = pd.read_html(StringIO(str(table)))[0]
            except:
                continue
            encontrado = encontrar_jogador(df_box, player_name)
            if not encontrado: continue
            idx, df_box = encontrado
            return {
                "Pontos": df_box.loc[idx, "PTS"] if "PTS" in df_box.columns else "",
                "Rebotes": df_box.loc[idx, "TRB"] if "TRB" in df_box.columns else "",
                "Assistências": df_box.loc[idx, "AST"] if "AST" in df_box.columns else "",
                "Roubos": df_box.loc[idx, "STL"] if "STL" in df_box.columns else "",
                "Tocos": df_box.loc[idx, "BLK"] if "BLK" in df_box.columns else "",
                "Bolas de 3": df_box.loc[idx, "3P"] if "3P" in df_box.columns else "",
                "Turnovers": df_box.loc[idx, "TOV"] if "TOV" in df_box.columns else ""
            }
        return vazio
    except Exception:
        return vazio

def preparar_dataframe_worksheet(ws):
    values = ws.get_all_values()
    if not values: return None, None
    df = pd.DataFrame(values)
    header = df.iloc[0].tolist()
    df = df[1:].reset_index(drop=True)
    df.columns = header
    if not all(col in df.columns for col in COLUNAS_OBRIGATORIAS):
        return None, None
    for col in COLUNAS_STATS:
        if col not in df.columns:
            df[col] = ""
    return df, header

def a1_col(col_num):
    result = ""
    while col_num > 0:
        col_num, remainder = divmod(col_num - 1, 26)
        result = chr(65 + remainder) + result
    return result

def processar_aba(ws):
    df, header = preparar_dataframe_worksheet(ws)
    if df is None:
        print(f"[{ws.title}] ignorada: estrutura incompatível")
        return
    print(f"
Aba: {ws.title}")
    stats_col_idx = {col: header.index(col) + 1 for col in COLUNAS_STATS if col in header}
    updates = []
    for i, row in df.iterrows():
        jogador = str(row.get("Jogadores", "")).strip()
        mandante = str(row.get("Time Mandante", "")).strip()
        data_txt = str(row.get("Data", "")).strip()
        if not jogador or not mandante or not data_txt:
            continue
        if str(row.get("Pontos", "")).strip():
            continue
        game_date = parse_data(data_txt)
        if not game_date:
            continue
        team_abbr = NBA_TEAMS.get(mandante, mandante[:3].upper())
        stats = find_player_stats(team_abbr, game_date, jogador)
        sheet_row = i + 2
        for stat_col in COLUNAS_STATS:
            if stat_col in stats_col_idx:
                cell_a1 = f"{a1_col(stats_col_idx[stat_col])}{sheet_row}"
                updates.append({"range": cell_a1, "values": [[stats.get(stat_col, "")]]})
        time.sleep(1.2)
    if updates:
        ws.batch_update(updates)
        print(f"  ✅ {len(updates)} células atualizadas em {ws.title}")
    else:
        print(f"  ℹ Nenhuma atualização necessária em {ws.title}")

def processar_todas_as_abas():
    sh = conectar_gsheets()
    for ws in sh.worksheets():
        processar_aba(ws)
    print("
Concluído.")

if __name__ == "__main__":
    processar_todas_as_abas()
