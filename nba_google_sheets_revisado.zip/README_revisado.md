# NBA Google Sheets - versão revisada

## Esta versão faz 2 coisas
1. Teste de escrita usando `update_acell()`.
2. Versão principal protegida contra gravação de valores vazios.

## Configurações no topo do script
- `ABA_TESTE = None` -> defina o nome da aba para testar só uma.
- `APENAS_TESTE_ESCRITA = True` -> testa apenas escrita e não entra nas stats.
- `CELULA_TESTE = "E2"` -> célula do teste.
- `VALOR_TESTE = "999"` -> valor do teste.

## Fluxo sugerido
1. Rode com `APENAS_TESTE_ESCRITA = True`.
2. Verifique a URL impressa no terminal.
3. Confira exatamente essa planilha e essa aba.
4. Se funcionar, troque para `False` e teste o preenchimento real.

## Correções incluídas
- `game_id = f"{game_date}0{team_abbr}"`
- uso de `update_acell()`
- proteção para não gravar stats vazias
- impressão da URL exata da planilha
