# Etapa 4 v4 - Elencos Fantasy NBA

## Entregas desta etapa
- Seletor de temporada reaproveitado.
- Salários e team options visíveis por ano.
- Total salarial por temporada.
- Cap restante da development calculado como 14.000.000 - salários.

## Como rodar
```bash
streamlit run elenco.py
```
